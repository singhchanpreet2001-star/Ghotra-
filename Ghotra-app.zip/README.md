# Ghotra Transport — dispatch en chauffeursapp

Eén app met twee ingangen:

- **Dispatch** (kantoor): planning, ritten, kalender met ziekte en verlof, mail, rit uit PDF, CMR-controle, facturen, documenten, logins en een assistent.
- **Chauffeursapp** (telefoon of tablet): eigen ritten, grote knoppen per stap, CMR-foto, route en meldingen.

Iedereen logt in op hetzelfde adres. Kantoor komt in de dispatch, een chauffeur in de chauffeursapp. Een chauffeur ziet alleen zijn eigen ritten, zonder prijzen, en kan niet in de dispatch. Dat controleert de server zelf.

De app heeft geen extra pakketten nodig. Hij draait op Node.js 22 en bewaart alles in één map (`/data`).

---

## 1. Online zetten op Railway (eenmalig, ongeveer 15 minuten)

### a. Code in GitHub zetten
Doe dit op een computer.

1. Pak de zip uit.
2. Open je repository op GitHub: `github.com/singhchanpreet2001-star/Ghotra-`.
3. Klik op **Add file → Upload files**. Is de repo nog leeg, dan klik je op de link **uploading an existing file**.
4. Sleep **alles uit de uitgepakte map** naar het venster: `server.js`, `package.json`, `README.md`, `.gitignore` en de mappen `lib` en `public`.
5. Klik onderaan op **Commit changes**.

### b. Railway koppelen
1. Ga naar **railway.com**, open je project of maak een nieuw project.
2. Kies **New → GitHub Repo** en selecteer `Ghotra-`. Railway vraagt de eerste keer om toegang tot GitHub.
3. Railway herkent de app zelf en start hem met `npm start`.

### c. Opslag toevoegen (belangrijk)
Zonder dit ben je je gegevens kwijt bij elke update.
1. Open de service → **Settings → Volumes → Add Volume**.
2. Zet **Mount path** op `/data`.

### d. Variabelen invullen
Ga naar de service → **Variables** en voeg toe:

| Naam | Waarde |
|---|---|
| `DATA_DIR` | `/data` |
| `ADMIN_EMAIL` | je eigen e-mailadres (eerste beheerder) |
| `ADMIN_PASSWORD` | een sterk wachtwoord van minstens 8 tekens |

`ADMIN_EMAIL` en `ADMIN_PASSWORD` gebruikt de app alleen bij de allereerste start. Daarna kun je je wachtwoord in de app wijzigen.

### e. Adres aanmaken
Ga naar **Settings → Networking → Generate Domain**. Je krijgt een adres zoals `ghotra-production.up.railway.app`. Open het en log in met je beheerdersgegevens.

Een eigen domein, zoals `app.ghotra.be`, voeg je toe op dezelfde plek via **Custom Domain**.

---

## 2. Eerste keer in de app

1. **Beheer → Bedrijfsgegevens**: naam, adres, btw-nummer, IBAN en telefoon. Die komen op facturen en CMR's.
2. **Beheer → Koppelingen**: mail, AI en vrachtwagenroutes. Zie hieronder.
3. **Beheer → Voertuigen**: kenteken en maten (hoogte, breedte, lengte, massa). De maten zijn nodig voor de vrachtwagenroutes.
4. **Beheer → Chauffeurs**: voeg je chauffeurs toe. Open een chauffeur en klik op **Login aanmaken**. De app maakt een wachtwoord. Geef dat aan de chauffeur, of stuur het met één klik per mail.
5. **Beheer → Logins**: kantoorcollega's toevoegen, als *Dispatch* of als *Beheerder*.

Elk onderdeel werkt los. Is iets nog niet ingesteld, dan werkt de rest gewoon.

---

## 3. Koppelingen

### Mail (Gmail, Google Workspace of eigen domein)
De app leest je mailbox via IMAP en verstuurt via SMTP. Mails komen dus gewoon uit je eigen adres en staan ook in Gmail bij "Verzonden".

**Gmail of Google Workspace** (ook met je eigen domein):
1. Zet **tweestapsverificatie** aan op `myaccount.google.com/security`.
2. Ga naar `myaccount.google.com/apppasswords`, maak een app-wachtwoord met de naam "Ghotra" en kopieer de 16 tekens.
3. Vul in de app bij **Beheer → Koppelingen → Mail** je e-mailadres en dat app-wachtwoord in. De servers vult de app zelf in. Klik op **Verbinding testen**.

Bij Google Workspace moet de beheerder van het domein IMAP en app-wachtwoorden toestaan.

**Andere provider** (bv. Combell, one.com, Outlook): vul de IMAP-server (poort 993) en SMTP-server (poort 465) van je provider in. Een kopie van verzonden mail komt automatisch in je map Verzonden.

### AI: PDF-opdrachten, CMR-controle en assistent
1. Maak een account op `console.anthropic.com` en een sleutel bij **API Keys**.
2. Vul de sleutel in bij **Beheer → Koppelingen → AI**.

Je betaalt per gebruik. De kosten per opdracht of CMR zijn klein; je ziet het verbruik in de console van Anthropic.

### Vrachtwagenroutes (HERE)
1. Maak een account op `platform.here.com` en maak een API-sleutel.
2. Vul die in bij **Beheer → Koppelingen → Vrachtwagenroutes**.
3. Vul bij elk voertuig de hoogte, breedte, lengte en massa in.

De route houdt rekening met die maten, met ADR (tunnelcategorie) en met het actuele verkeer. Zonder HERE-sleutel tonen de knoppen een gewone route in Google Maps.

---

## 4. Werkwijze

1. **Opdracht komt binnen per mail.** Open in **Mail** het bericht en tik bij de PDF op **Rit maken**. De app leest de opdracht en vult het ritformulier in. Controleer en sla op.
2. **Chauffeur kiezen.** Afwezige chauffeurs (ziek, verlof) staan grijs en zijn niet te kiezen.
3. **De chauffeur krijgt een melding** en ziet de rit in zijn app. In de dispatch zie je "Gezien" zodra hij hem opent.
4. **Onderweg** tikt de chauffeur de stappen aan: Vertrek naar laadplaats → Laden → Vertrek naar losplaats → Lossen. Jij ziet elke stap live, met het uur. Tijdens de rit zie je ook zijn laatste positie.
5. **CMR is verplicht.** Na het lossen maakt de chauffeur een foto van de ondertekende CMR. De app controleert die (handtekening, datum, aantallen, voorbehoud) en maakt meteen een **conceptfactuur**.
6. **Jij controleert** de conceptfactuur: het mailadres van de klant, de bedragen, de btw en het bericht. Daarna klik je op **Goedkeuren en versturen**. Factuur en CMR gaan samen als bijlage mee.

**Ziek melden** kan de chauffeur zelf in zijn app (menu). Kantoor krijgt meteen een melding, en ritten die hem nog hebben komen op Vandaag in het rood.

---

## 5. De chauffeursapp installeren

Op de telefoon of tablet van de chauffeur:
1. Open het adres van de app en log in.
2. **Android (Chrome):** menu ⋮ → **App installeren** of **Toevoegen aan startscherm**.
   **iPhone/iPad (Safari):** Deel-knop → **Zet op beginscherm**. Open de app daarna vanaf het beginscherm.
3. Tik in de app op **Meldingen aanzetten**.

Meldingen op iPhone en iPad werken vanaf iOS 16.4, en alleen als de app op het beginscherm staat.

---

## 6. Back-up

Alle gegevens staan in de map `/data` op het Railway-volume:
- `ghotra.db`: ritten, klanten, facturen, logins en instellingen
- `files/`: CMR's, opdracht-PDF's en documenten

Zet in Railway back-ups aan voor dit volume (bij de instellingen van het volume), of kopieer de map af en toe naar een veilige plek.

---

## 7. Voor een ontwikkelaar

- `server.js`: HTTP-server, rechten, API, live updates (server-sent events), CMR-verwerking
- `lib/db.js`: SQLite (ingebouwd in Node 22), gegevens als JSON-documenten per collectie
- `lib/auth.js`: scrypt-wachtwoorden, sessiecookies (HttpOnly, SameSite=Lax), rollen `admin`, `dispatch` en `driver`
- `lib/mail.js` en `lib/mime.js`: IMAP- en SMTP-client en MIME-verwerking
- `lib/ai.js`: Anthropic Messages API (PDF en foto als invoer, assistent met tools die alleen lezen)
- `lib/push.js`: Web Push met VAPID, zonder inhoud. De service worker haalt de melding zelf op.
- `lib/here.js`: HERE geocoding en truck routing v8, plus flexible polyline decoder
- `public/`: `dispatch.html` en `assets/dispatch.js` (kantoor), `driver.html` en `assets/driver.js` (chauffeur), `login.html`, `sw.js`

Lokaal starten: `npm run dev` (Node 22.13 of nieuwer), daarna `http://localhost:3000`.

Optionele variabelen: `MAIL_USER`, `MAIL_PASS`, `MAIL_IMAP_HOST`, `MAIL_SMTP_HOST`, `MAIL_FROM_NAME`, `ANTHROPIC_API_KEY`, `ANTHROPIC_MODEL`, `HERE_API_KEY`, `VAPID_SUBJECT`. Staan ze ingevuld, dan gaan ze voor op de instellingen in de app.
